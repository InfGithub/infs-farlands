#include <stdio.h>
#include <stdint.h>
#include <assert.h>

/* ---------- 原始 H ---------- */
static uint64_t H(uint32_t x)
{
    uint64_t v = x;
    v *= 0xff51afd7ed558ccdULL;
    v ^= v >> 33;
    v *= 0xc4ceb9fe1a85ec53ULL;
    v ^= v >> 33;
    return v;
}

/* ---------- 逆右移异或 ---------- */
static uint64_t unshift_xor(uint64_t v, int shift)
{
    uint64_t x = v;
    for (int s = shift; s < 64; s <<= 1)
        x ^= x >> s;
    return x;
}

/* ---------- 预计算的乘法逆元（Python 验证） ---------- */
static const uint64_t INV_M2 = 0x9cb4b2f8129337dbULL; // M2的模2^64逆元
static const uint64_t INV_M1 = 0x4f74430c22a54005ULL; // M1的模2^64逆元

/* ---------- 逆函数（无动态逆元计算） ---------- */
static int inverse_H(uint64_t y, uint32_t *out)
{
    uint64_t v = y;
    v = unshift_xor(v, 33);
    v *= INV_M2;
    v = unshift_xor(v, 33);
    v *= INV_M1;
    if (v >> 32)
        return 0; // 高32位非零 → 不在像集中
    *out = (uint32_t)v;
    return 1;
}

int main(void)
{
    printf("=== Phase 1: Verify inverse_H for all 2^32 inputs ===\n");
    uint64_t limit = 1ULL << 32;
    for (uint64_t x = 0; x < limit; x++)
    {
        uint32_t ix = (uint32_t)x;
        uint64_t y = H(ix);
        uint32_t recovered;
        if (!inverse_H(y, &recovered) || recovered != ix)
        {
            printf("FAIL at x = %u\n", ix);
            return 1;
        }
        if ((x & 0x0FFFFFFF) == 0)
        {
            printf("  progress: %.1f%%\r", (double)x / (double)limit * 100.0);
            fflush(stdout);
        }
    }
    printf("\nAll 2^32 inputs passed. inverse_H is correct.\n\n");

    /* ---------- Phase 2: Test all 16 candidate Deltas ---------- */
    printf("=== Phase 2: Check all 16 candidate Deltas ===\n");
    uint32_t vals[4] = {0x00000000, 0xFFFFFFFF, 0x80000000, 0x7FFFFFFF};
    const char *names[4] = {"0", "0xFFFFFFFF", "0x80000000", "0x7FFFFFFF"};

    int all_clear = 1;
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            uint64_t delta = ((uint64_t)vals[i] << 32) | vals[j];
            if (delta == 0)
                continue;

            uint32_t out;
            if (inverse_H(delta, &out))
            {
                printf("Delta = (%-11s << 32) | %-11s = 0x%016llx  IS IN IMAGE (i=%u)\n",
                       names[i], names[j], (unsigned long long)delta, out);
                printf("  *** WARNING: Potential non-trivial identity might exist! ***\n");
                all_clear = 0;
            }
            else
            {
                printf("Delta = (%-11s << 32) | %-11s = 0x%016llx  NOT in image.\n",
                       names[i], names[j], (unsigned long long)delta);
            }
        }
    }

    printf("\n");
    if (all_clear)
    {
        printf("All 15 non-trivial Deltas are NOT in the image of H.\n");
        printf("Conclusion: No non-trivial arithmetic identity exists.\n");
    }
    else
    {
        printf("Some Delta(s) found in image - further analysis required.\n");
    }

    return 0;
}