# 作者说明

本项目（哈希函数安全性证明及验证程序）由 **Infinitive** 完成。

- **作者**: Infinitive
- **联系方式**: Yao_icft@outlook.com

如有疑问或需进一步讨论，请通过上述邮箱联系。