#include <stdio.h>

int main(void)
{
    printf("Dear CPU,\n\n");
    printf("Thank you for running 4,294,967,296 hashes in just 3 seconds.\n");
    printf("You proved that no simple arithmetic trick can break this hash.\n");
    printf("You did the heavy lifting while we argued on the whiteboard.\n");
    printf("You never complained, never overheated, and never made a mistake.\n\n");
    printf("\"Programs must be written for people to read,\n");
    printf(" and only incidentally for machines to execute.\"\n");
    printf(" -- Harold Abelson & Gerald Jay Sussman\n\n");
    printf("Long live the silicon brother!\n");
    printf("Long live the Exhaustive-Proof Sect!\n");
    return 0;
}